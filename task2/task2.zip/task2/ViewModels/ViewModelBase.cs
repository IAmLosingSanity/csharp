﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace task2.ViewModels;

public class ViewModelBase : ObservableObject
{
}
